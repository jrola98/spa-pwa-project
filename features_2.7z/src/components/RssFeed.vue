<template>
  <Loader v-if="this.isLoading" />
  <div v-else>
    <b-form v-if="this.showInputUrlField">
      <b-form-group>
        <label for="userData-input">RSS feed url</label>
        <b-input id="userData" v-model="inputField" required></b-input>
      </b-form-group>
      <b-button class="reddish" @click="this.saveRssUrl" variant="primary">Save data!</b-button>
    </b-form>    
    <VueRssFeed v-else :feedUrl="feedUrl" :name="name" :limit="limit"/>
  </div>
</template>

<script>
import firebase from 'firebase';
import VueRssFeed from "vue-rss-feed";
import Loader from "./Loader"

export default {
  name: "RssFeed",
  components: {
    VueRssFeed,
    Loader
  },
  data: () =>  ({
    feedUrl: "",
    name: "Rss Feed", 
    limit: 1,
    isLoading: false,
    showInputUrlField: false,
    inputField: '',
  }),
  methods: {
    checkForSavedRSS: async function() {
      const db = firebase.firestore();
      const appUser = localStorage.getItem('spa-pwa-project');
      const docRef = db.collection(appUser).doc('rssFeed');
      this.isLoading = true;
      await docRef.get()
      .then((querySnapshot) => {
        console.log(querySnapshot.data())
        if (querySnapshot.data()) {
          this.feedUrl = `https://cors-anywhere.herokuapp.com/${querySnapshot.data().url}`;
          this.showInputUrlField = false;
          this.isLoading = false;
        } else {
          this.showInputUrlField = true;
          this.isLoading = false
        }
      })
    },
    saveRssUrl: function() {
      const db = firebase.firestore();
      const appUser = localStorage.getItem('spa-pwa-project');
      const docRef = db.collection(appUser).doc('rssFeed');
      docRef.set({
        url: this.inputField
      })
      alert('URL saved!');
      this.checkForSavedRSS();
    }
  },
  mounted: function() { 
    this.checkForSavedRSS();
    console.log(this.feedUrl)
  }
}
</script>

// https://cprss.s3.amazonaws.com/frontendfoc.us.xml