/*<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.13.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.13.1/firebase-analytics.js"></script>

<script>
  // Your web app's Firebase configuration
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
</script>
*/


export const firebaseConfig = {
  apiKey: "AIzaSyBaOA1CrT4NE9zRzYEb3yib3ZXgtTd3v1E",
  authDomain: "spa-pwa-project.firebaseapp.com",
  databaseURL: "https://spa-pwa-project.firebaseio.com",
  projectId: "spa-pwa-project",
  storageBucket: "spa-pwa-project.appspot.com",
  messagingSenderId: "138056385286",
  appId: "1:138056385286:web:0f211a28cfde6776aa5487",
  measurementId: "G-YMQWP6VR91"
};

export const admin = {
  login: 'admin@test.com',
  password: 'password',
}