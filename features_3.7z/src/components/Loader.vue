<template>
  <div>
    <b-spinner style="width: 3rem; height: 3rem;" class="m-5" label="Busy"></b-spinner>
  </div>
</template>

<script>
export default {
  name: 'Loader',
}
</script>